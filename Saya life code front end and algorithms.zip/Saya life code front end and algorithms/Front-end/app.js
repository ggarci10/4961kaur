function getData() {
  var durationInput = document.getElementById("durationInput").value;
  var volumeIpnut = document.getElementById("volumeInput").value;
  var eventFlowRateInput = document.getElementById("eventFlowRateInput").value;
  var sqrfInput = document.getElementById("sqrfInput").value;
  var yearInput = document.getElementById("yearInput").value;
  var numWorkersInput = document.getElementById("numWorkersInput").value;
  var waterClassify = document.querySelector(
    'input[name="waterClassify"]:checked'
  ).value;
  var buildingTypeInput = document.getElementById("buildingTypeCheckbox")
    .checked
    ? 1
    : 0;
  var regionInput = document.getElementById("coldCheckbox").checked ? 1 : 0;
  var uploadStatus = document.getElementById("uploadStatus");
  var yearError = document.getElementById("yearError");
  var sqrfError = document.getElementById("sqrfError");
  var numWorkersError = document.getElementById("numWorkersError");

  // Validate Square Footage
  if (isNaN(sqrfInput) || sqrfInput.trim() === "") {
    sqrfError.textContent = "Please enter a valid number for Square Footage.";
    return;
  } else {
    sqrfError.textContent = "";
  }

  // Validate year
  var currentYear = new Date().getFullYear();
  if (!/^(19|20)\d{2}$/.test(yearInput) || parseInt(yearInput) > currentYear) {
    yearError.textContent = "Please enter a valid year (2024 or earlier).";
    return;
  } else {
    yearError.textContent = "";
  }

  // Validate Number of Workers
  if (
    !Number.isInteger(parseInt(numWorkersInput)) ||
    numWorkersInput.trim() === ""
  ) {
    numWorkersError.textContent =
      "Please enter a valid integer for Number of Workers.";
    return;
  } else {
    numWorkersError.textContent = "";
  }

  var waterCon = [0, 0, 0];
  waterCon[parseInt(waterClassify)] = 1;

  var url = "http://127.0.0.1:5000/predict"; // Use this if  you are using nginx. i.e tutorial 8 and onwards

  $.post(
    url,
    {
      duration: parseFloat(durationInput),
      volume: parseFloat(volumeIpnut),
      eventFlowRate: parseFloat(eventFlowRateInput),
      sqrf: parseInt(sqrfInput),
      year: currentYear - parseInt(yearInput),
      numWorkers: parseInt(numWorkersInput),
      highCon: waterCon[0],
      medCon: waterCon[1],
      lowCon: waterCon[2],
      buildingType: parseInt(buildingTypeInput),
      region: parseInt(regionInput),
    },

    function (data, status) {
      console.log(data.prediction);

      // Display result
      var textColor = "green";
      if (data.prediction.toString() === "Yes") {
        textColor = "red";
      }
      uploadStatus.innerHTML =
        "<span style='color: " +
        textColor +
        "'> " +
        data.prediction.toString() +
        "</span>";
      console.log(status);
    }
  );
}

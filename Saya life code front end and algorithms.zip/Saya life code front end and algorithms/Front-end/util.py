import pickle
import numpy as np

__model = None

def get_result(duration, volume, eventFlowRate, SQRF, numberOfWorkers, BuildAge, WaterClassify_HighCon, WaterClassify_LowCon,
               WaterClassify_MedCon, BuildingType_Office, ClimateRegion_Verycold_Cold):
    print("get result called")
    input_data = np.array([duration, volume, eventFlowRate, SQRF, numberOfWorkers, BuildAge, WaterClassify_HighCon, WaterClassify_LowCon,
               WaterClassify_MedCon, BuildingType_Office, ClimateRegion_Verycold_Cold])
    input_data_reshaped = input_data.reshape(1, -1)  # Reshape to 2D array
    prediction = __model.predict(input_data_reshaped)
    print("Prediction:", prediction[0])
    return prediction[0]

def load_files():
    global __model
    with open("projectPickle.pkl", 'rb') as f:
        __model = pickle.load(f)
        print("Pickle loaded")

if __name__ == "__main__":
    load_files()

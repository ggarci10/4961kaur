from flask import Flask, request, jsonify
import util
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/predict', methods=['POST'])
def get_result():
    print("server connected")
    duration = float(request.form['duration'])
    volume = float(request.form['volume'])
    eventFlowRate = float(request.form['eventFlowRate'])
    sqrf = int(request.form['sqrf'])
    numWorkers = int(request.form['numWorkers'])
    buildingAge = int(request.form['year'])
    HighCon = int(request.form['highCon'])
    LowCon = int(request.form['lowCon'])
    MedCon = int(request.form['medCon'])
    isOffice = int(request.form['buildingType'])
    isColdRegion = int(request.form['region'])

    response = jsonify({
        'prediction': util.get_result(duration, volume, eventFlowRate,sqrf,numWorkers,buildingAge,HighCon,LowCon,MedCon,isOffice,isColdRegion)
    })
    response.headers.add('Access-Control-Allow-Origin', '*')
    
    return response

if __name__ == '__main__':
    util.load_files()
    app.run()

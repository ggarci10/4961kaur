from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return 'Welcome to the Flask server!'

@app.route('/data')
def get_data():
    # Replace this with your actual data retrieval logic
    data = {
        'example_data': [1, 2, 3, 4, 5]
    }
    return jsonify(data)

if __name__ == '__main__':
    app.run()
